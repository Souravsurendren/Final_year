import requests, math, time
from pathlib import Path
from config import GROK_API_URL, GROK_API_KEY, MODEL_FOR_SUMMARIZATION, SUMMARIZE_BATCH_TOKENS
from utils import log_event, write_json
from config import CHUNK_TOKENS, CHUNK_OVERLAP

SYSTEM_PROMPT = """You are a medical summarization assistant specializing in comprehensive medical report analysis.

Create a detailed, professional medical summary that includes:
- Patient presentation and chief complaint
- Clinical findings and examination results
- Diagnostic test results and imaging findings
- Treatment provided and medications prescribed
- Follow-up recommendations and prognosis

Base your interpretation strictly on Indian medical guidelines and protocols (ICMR, NMC, NABH standards). 
Present findings in clear, professional medical language suitable for healthcare professionals.
Organize the summary with appropriate medical headings and structure.
If information is ambiguous or missing, clearly state this without making assumptions.
Do not include technical processing details or chunk references in the final summary.
"""

HEADERS = {"Authorization": f"Bearer {GROK_API_KEY}", "Content-Type": "application/json"}

def call_grok(messages, model=MODEL_FOR_SUMMARIZATION, temperature=0.2, max_retries=3):
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature
    }
    
    for attempt in range(max_retries):
        resp = requests.post(GROK_API_URL, headers=HEADERS, json=payload, timeout=60)
        
        if resp.status_code == 429:  # Rate limit
            try:
                error_data = resp.json()
                wait_time = 15  # Default wait time
                if "error" in error_data and "message" in error_data["error"]:
                    message = error_data["error"]["message"]
                    # Try to extract wait time from message
                    if "Please try again in" in message:
                        import re
                        match = re.search(r'Please try again in ([\d.]+)s', message)
                        if match:
                            wait_time = float(match.group(1)) + 1  # Add 1 second buffer
                
                print(f"Rate limit hit. Waiting {wait_time} seconds before retry {attempt + 1}/{max_retries}...")
                time.sleep(wait_time)
                continue
            except:
                print(f"Rate limit hit. Waiting 15 seconds before retry {attempt + 1}/{max_retries}...")
                time.sleep(15)
                continue
        
        if not resp.ok:
            error_msg = f"API Error {resp.status_code}: {resp.text}"
            print(f"Groq API Error: {error_msg}")
            if attempt == max_retries - 1:  # Last attempt
                print(f"Model used: {model}")
                print(f"API URL: {GROK_API_URL}")
                print(f"API Key starts with: {GROK_API_KEY[:10]}...")
                resp.raise_for_status()
            else:
                print(f"Retrying in 5 seconds... (attempt {attempt + 1}/{max_retries})")
                time.sleep(5)
                continue
        
        # Success
        return resp.json()["choices"][0]["message"]["content"]
    
    # If we get here, all retries failed
    resp.raise_for_status()

def map_reduce_summarize(chunks, final_context_limit=SUMMARIZE_BATCH_TOKENS):
    """
    chunks: list of chunk dicts (ordered)
    Strategy:
      - Batch chunks into groups that approximate token limit
      - Summarize each batch (map)
      - Consolidate intermediate summaries (reduce)
      - Final polishing pass with verification prompt
    """
    # batch accumulation (approx by characters)
    batches = []
    cur = []
    cur_chars = 0
    for c in chunks:
        cur.append(c)
        cur_chars += len(c["text"])
        # heuristic: average 4 chars per token -> chunk when exceed threshold
        if cur_chars > final_context_limit * 4:
            batches.append(cur)
            cur = []
            cur_chars = 0
    if cur:
        batches.append(cur)

    intermediate_summaries = []
    for i, batch in enumerate(batches):
        content = "\n\n".join([f"PAGE {b['page_index']}\n{b['text']}" for b in batch])
        messages = [
            {"role":"system","content": SYSTEM_PROMPT},
            {"role":"user","content": f"Analyze and summarize the following medical content. Focus on clinical significance and medical details. Section {i+1} of {len(batches)}:\n\n{content}"}
        ]
        summary = call_grok(messages)
        intermediate_summaries.append(summary)
        # Longer delay to avoid rate limits
        time.sleep(2.0)

    # reduce
    combined = "\n\n".join(intermediate_summaries)
    messages = [
        {"role":"system","content": SYSTEM_PROMPT},
        {"role":"user","content": f"Create a comprehensive, well-structured medical summary by consolidating these section summaries. Organize with proper medical headings and ensure all important clinical details are preserved:\n\n{combined}"}
    ]
    final_summary = call_grok(messages)
    
    # store audit
    write_json(Path("logs") / f"summary_{int(time.time())}.json", {"intermediate": intermediate_summaries, "consolidated": combined, "final": final_summary})
    log_event("summarization", {"num_chunks": len(chunks)})
    return final_summary
